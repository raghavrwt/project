/**
 * _refreshPageData() will call automatically when page loaded Calling
 * _refreshPageData() after every add & Remove of data
 */

var myWebservice = angular.module("myApp", []);

myWebservice
		.controller(
				"ServiceController",
				function($scope, $http) {
					_refreshPageData();
					// Check url according to your Application name & PORT
					function _refreshPageData() {
						$http(
								{
									method : 'GET',
									url : 'http://localhost:8089/InstaInsuranceV6.2/a/getTempQuotes.json'
								}).success(function(data) {
							

						});
					}
					$scope.form = {
						countryId : 1,
						countryName : "",
						population : ""

					};

					$scope.add = function() {

						$http(
								{
									method : 'POST',
									url : 'http://localhost:8089/InstaInsuranceV6.2/a/insertTempQuotes/'
										+ $scope.form.vehicle_age
										+ '/'
										+ $scope.form.vehicle_type
										+ '/'
										+ $scope.form.vehicle_registration
										+ '/'
										+ $scope.form.vechile_name
										+ '/'
										+ $scope.form.vehicle_variant
										+ '/'
										+ $scope.form.vehicle_place
										+ '/'
										+ $scope.form.vehicle_fuel
										+ '/'
										+ $scope.form.firstName
										+ '/'
										+ $scope.form.lastName
										+ '/'
										+ $scope.form.emailId
										+ '/'
										+ $scope.form.contactNumber
										+ '/'
										+ $scope.form.vehicle_maker
										}).success(function(data) {
											$scope.policies = data; 
							/*alert("Your response is successfully added , Thank You");*/
							_refreshPageData();

						});

					}
					$scope.remove = function(data) {

						// Check url according to your Application name & PORT
						$http(
								{
									method : 'DELETE',
									url : 'http://localhost:8089/SpringRest020/rest/countries/delete/'
											+ data
								}).success(function(data) {
							alert('Data Deleted')
							_refreshPageData();

						});

					}

				});
