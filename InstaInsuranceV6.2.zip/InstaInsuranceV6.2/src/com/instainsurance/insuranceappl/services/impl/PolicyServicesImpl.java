package com.instainsurance.insuranceappl.services.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.instainsurance.insuranceappl.daos.PolicyDao;
import com.instainsurance.insuranceappl.models.Policy;
import com.instainsurance.insuranceappl.services.PolicyServices;

@Service("PolicyServices")
public class PolicyServicesImpl implements PolicyServices {

	@Resource
	private PolicyDao dao;
	
	@Override
	public Boolean insertPolicy(Policy policy) {
		return dao.insertPolicy(policy);
	}

	@Override
	public Boolean updatePolicy(Policy policy) {
		return dao.updatePolicy(policy);
	}

	@Override
	public Boolean deletePolicy(Policy policy) {
		return dao.deletePolicy(policy);
	}

	@Override
	public Policy findByPolicyId(String id) {
		return dao.findByPolicyId(id);
	}

	@Override
	public List<Policy> getPolicies() {
		return dao.getPolicies();
	}

	@Override
	public List<Policy> getPolicies(String category) {
		System.out.println("PolicyServicesImpl : "+ category);
		return dao.getPolicies(category);
	}

}
