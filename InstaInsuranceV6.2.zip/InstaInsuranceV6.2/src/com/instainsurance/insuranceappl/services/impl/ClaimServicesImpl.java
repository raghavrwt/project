package com.instainsurance.insuranceappl.services.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.instainsurance.insuranceappl.daos.ClaimDao;
import com.instainsurance.insuranceappl.daos.IncidentReportDao;
import com.instainsurance.insuranceappl.exceptions.InsuranceException;
import com.instainsurance.insuranceappl.models.Claim;
import com.instainsurance.insuranceappl.services.ClaimServices;

@Service
public class ClaimServicesImpl implements ClaimServices {

	@Resource
	private ClaimDao dao;
	
	@Override
	public Boolean insertClaim(Claim claim) throws InsuranceException {
		System.out.println(claim);
		return dao.insertClaim(claim);
	}

	@Override
	public Boolean updateClaim(Claim claim) throws InsuranceException {
		return dao.updateClaim(claim);
	}

	@Override
	public Boolean deleteClaim(Claim claim) throws InsuranceException {
		return dao.deleteClaim(claim);
	}

	@Override
	public Claim findByClaimId(String id) throws InsuranceException {
		return dao.findByClaimId(id);
	}

	@Override
	public List<Claim> getClaims() throws InsuranceException {
		return dao.getClaims();
	}

}
