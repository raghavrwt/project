package com.instainsurance.insuranceappl.services.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.instainsurance.insuranceappl.daos.CustomerDao;
import com.instainsurance.insuranceappl.models.Customer;
import com.instainsurance.insuranceappl.services.CustomerServices;

@Service
public class CustomerServicesImpl implements CustomerServices{
	
	@Resource
	private CustomerDao dao;
	
	@Override
	public Boolean insertCustomer(Customer customer) {
		return dao.insertCustomer(customer);
	}

	@Override
	public Boolean updateCustomer(Customer customer) {
		return dao.updateCustomer(customer);
	}

	@Override
	public Boolean deleteCustomer(Customer customer) {
		return dao.deleteCustomer(customer);
	}

	@Override
	public Customer findByCustomerId(String id) {
		return dao.findByCustomerId(id);
	}

	@Override
	public List<Customer> getCustomer() {
		return dao.getCustomer();
	}
//
//	@Override
//	public Customer checkLogin(String userName, String userPassword) {
//	
//		return dao.checkLogin(userName, userPassword);
//	}

}
