package com.instainsurance.insuranceappl.services.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.instainsurance.insuranceappl.daos.IncidentDao;
import com.instainsurance.insuranceappl.daos.TempQuoteDao;
import com.instainsurance.insuranceappl.exceptions.InsuranceException;
import com.instainsurance.insuranceappl.models.Incident;
import com.instainsurance.insuranceappl.services.IncidentServices;

@Service
public class IncidentServicesImpl implements IncidentServices {

	
	@Resource
	private IncidentDao dao;
	
	@Override
	public Boolean insertIncident(Incident incident) throws InsuranceException {
		return dao.insertIncident(incident);
	}

	@Override
	public Boolean updateIncident(Incident incident) throws InsuranceException {
		return dao.updateIncident(incident);
	}

	@Override
	public Boolean deleteIncident(Incident incident) throws InsuranceException {
		return dao.deleteIncident(incident);
	}

	@Override
	public Incident findByIncidentId(String id) throws InsuranceException {
		return dao.findByIncidentId(id);
	}

	@Override
	public List<Incident> getIncidents() {
		return dao.getIncidents();
	}

}
