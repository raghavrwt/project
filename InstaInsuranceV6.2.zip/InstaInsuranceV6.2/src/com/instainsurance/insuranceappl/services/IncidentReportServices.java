package com.instainsurance.insuranceappl.services;

import java.util.List;

import com.instainsurance.insuranceappl.exceptions.InsuranceException;
import com.instainsurance.insuranceappl.models.Incident;
import com.instainsurance.insuranceappl.models.IncidentReport;

public interface IncidentReportServices {

	Boolean insertIncidentReport(IncidentReport incidentReport) throws InsuranceException;
	Boolean updateIncidentReport(IncidentReport incidentReport) throws InsuranceException;
	Boolean deleteIncidentReport(IncidentReport incidentReport) throws InsuranceException;
	IncidentReport findByIncidentReportId(String id) throws InsuranceException;
	List<IncidentReport> getIncidentReports();
}
