package com.instainsurance.insuranceappl.services;

import java.util.List;

import com.instainsurance.insuranceappl.exceptions.InsuranceException;
import com.instainsurance.insuranceappl.models.Incident;

public interface IncidentServices {
	Boolean insertIncident(Incident incident) throws InsuranceException;
	Boolean updateIncident(Incident incident) throws InsuranceException;
	Boolean deleteIncident(Incident incident) throws InsuranceException;
	Incident findByIncidentId(String id) throws InsuranceException;
	List<Incident> getIncidents();
}
