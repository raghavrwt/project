package com.instainsurance.insuranceappl.services;

import com.instainsurance.insuranceappl.models.VehiclesData;

public interface VehiclesDataServices {
	Boolean insertVehicle(VehiclesData vehiclesData);
	Boolean updateVehicle(VehiclesData vehiclesData);
	Boolean deleteVehicle(VehiclesData vehiclesData);
	VehiclesData findByVehicleDataId(String id);
	
}
